﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gym.Models.Equipment.Contracts
{
    internal class BoxingGloves : Equipment
    {
        public BoxingGloves()
            : base(227, 120)
        {

        }
    }
}
