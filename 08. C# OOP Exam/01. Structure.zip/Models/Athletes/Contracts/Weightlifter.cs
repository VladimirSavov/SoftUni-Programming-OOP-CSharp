﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gym.Models.Athletes.Contracts
{
    internal class Weightlifter : Athlete
    {
        public Weightlifter(string fullName, string motivation, int numberOfMedals)
            : base(fullName, motivation, numberOfMedals, 50)
        {

        }
        public new void Exercise()
        {
            Weightlifter weightlifter = new Weightlifter(FullName, Motivation, NumberOfMedals);
            if(weightlifter.Stamina + 15 < 100)
            {
                weightlifter.Stamina = 100;
                throw new ArgumentException("Stamina cannot exceed 100 points.");
            }
        }
    }
}
