﻿using Gym.Models.Equipment.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gym.Repositories.Contracts
{
    internal class EquipmentRepository : IRepository<IEquipment>
    {
        private readonly List<IEquipment> equipments;
        public EquipmentRepository()
        {
            this.equipments = new List<IEquipment>();
        }

        public IReadOnlyCollection<IEquipment> Models => throw new NotImplementedException();

        public void Add(IEquipment model)
            => this.equipments.Add(model);

        public IEquipment FindByType(string type)
        {
            throw new InvalidOperationException("Invalid gym type.");

        }

        public bool Remove(IEquipment model)
        {
            if (equipments.Remove(model))
            {
                equipments.Remove(model);
                return true;
            }
            return false;
        }
    }
}
