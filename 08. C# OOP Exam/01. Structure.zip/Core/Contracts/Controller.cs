﻿using Gym.Models.Equipment.Contracts;
using Gym.Models.Gyms.Contracts;
using Gym.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Gym.Models.Athletes.Contracts;

namespace Gym.Core.Contracts
{
    internal class Controller : IController
    {
        private EquipmentRepository equipment;
        private ICollection<IGym> gyms;
        public string AddAthlete(string gymName, string athleteType, string athleteName, string motivation, int numberOfMedals)
        {
            if(athleteType == "Boxer")
            {
                Athlete boxer = new Boxer(athleteName, motivation, numberOfMedals);
                return $"Successfully added {athleteType} to {gymName}.";
            }
            else if(athleteType == "Weightlifter")
            {
                Athlete weightlifter = new Weightlifter(athleteName, motivation, numberOfMedals);
                return $"Successfully added {athleteType} to {gymName}.";
            }
            else
            {
                throw new InvalidOperationException("Invalid athlete type.");
            }
        }

        public string AddEquipment(string equipmentType)
        {
            if(equipmentType == "BoxingGloves")
            {
                IEquipment equipment = new BoxingGloves();
                return $"Successfully added {equipmentType}.";
            }
            else if(equipmentType == "Kettlebell")
            {
                IEquipment equipment = new BoxingGloves();
                return $"Successfully added {equipmentType}.";

            }
            else
            {
                throw new InvalidOperationException("Invalid equipment type.");
            }
        }

        public string AddGym(string gymType, string gymName)
        {
            if(gymType == "BoxingGym" ||  gymType == "WeightliftingGym")
            {
                AddGym(gymType, gymName);
                return $"Successfully added {gymType}.";
            }
            else
            {
                throw new InvalidOperationException("Invalid gym type.");
            }
        }

        public string EquipmentWeight(string gymName)
        {
            throw new NotImplementedException();
        }

        public string InsertEquipment(string gymName, string equipmentType)
        {
            IEquipment equipments = this.equipment.FindByType(equipmentType);
            if(equipments == null)
            {
                throw new InvalidOperationException($"There isn’t equipment of type {equipmentType}.");
            }
            this.equipment.Add(equipments);
            return $"Successfully added {equipmentType} to {gymName}.";
        }

        public string Report()
        {
            throw new NotImplementedException();
        }

        public string TrainAthletes(string gymName)
        {
            throw new NotImplementedException();
        }
    }
}
