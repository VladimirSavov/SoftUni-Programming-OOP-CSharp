namespace CarManager.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class CarManagerTests
    {
        [Test]
        public void TestConstructor()
        {
            //Arrange
            Car car = new Car("vv", "BMW", 11.5, 55);
            //Assert
            Assert.AreEqual("vv", car.Make);
            Assert.AreEqual("BMW", car.Model);
            Assert.AreEqual(11.5, car.FuelConsumption);
            Assert.AreEqual(55, car.FuelCapacity);
        }
        [Test]
        public void TestProperties() 
        {
            //Arrange
            Car car = new Car("vv", "BMW", 11.5, 55);
            //Assert
            Assert.AreEqual("vv", car.Make);
            Assert.AreEqual("BMW", car.Model);
            Assert.AreEqual(11.5, car.FuelConsumption);
            Assert.AreEqual(55, car.FuelCapacity);
        }
        [Test]
        public void RefuelTestBelowZero() 
        {
            //Arrange
            Car car = new Car("vv", "BMW", 11.5, 55);
            //Assert
            Assert.Throws<ArgumentException>(() => car.Refuel(-4));
        }
        [Test]
        public void RefuelTestAboveZero() 
        {
            //Arrange
            Car car = new Car("vv", "BMW", 11.5, 55);

            //Act
            car.Refuel(55);

            //Assert
            Assert.AreEqual(55, car.FuelAmount);
        }
        [Test]
        public void DriveTest()
        {
            //Arrange
            Car car = new Car("vv", "BMW", 10, 55);

            //Act
            car.Refuel(55);
            car.Drive(100);

            //Assert
            Assert.AreEqual(45, car.FuelAmount);
        }
        [Test]
        public void DriveTestThrowException()
        {
            //Arrange
            Car car = new Car("vv", "BMW", 10, 55);

            //Assert
            Assert.Throws<InvalidOperationException>(() => car.Drive(100));
        }
    }
}