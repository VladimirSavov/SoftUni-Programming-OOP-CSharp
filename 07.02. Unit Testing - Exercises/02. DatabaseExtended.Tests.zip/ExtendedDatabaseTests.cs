namespace DatabaseExtended.Tests
{
    using ExtendedDatabase;
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class ExtendedDatabaseTests
    {
        [Test]
        public void IfThereAreAlreadyUsersWithThisUsername()
        {
            //Arrange
            Database database = new Database();
            Person person = new Person(25, "Georgi");
            //Act
            database.Add(person);
            //Assert
            Assert.Throws<InvalidOperationException>(() => database.Add(person));   
        }
        [Test]
        public void IfThereAreAlreadyUsersWithThisID()
        {
            //Arrange
            Database database = new Database();
            Person person = new Person(26, "Pesho");
            Person person1 = new Person(26, "Niki");
            database.Add(person);
            //Act
            Assert.Throws<InvalidOperationException>(() => database.Add(person1));

        }
        [Test]
        public void FindByUsername()
        {
            //Arrange and Assert
            Database database = new Database();
            Assert.Throws<InvalidOperationException>(() => database.FindByUsername("Pesho")); 
        }
        [Test]
        public void FindByName()
        {
            //Arrange and Assert
            Database database = new Database();
            Assert.Throws<ArgumentNullException>(() => database.FindByUsername((string)null));
        }
        [Test]
        public void FindById()
        {
            //Arrange and Assert
            Database database = new Database();
            Assert.Throws<InvalidOperationException>(() => database.FindById(43));
        }
        [Test]
        public void FindByNameAndID() 
        { 
            //Arrange and Assert
            Database database = new Database();
            Assert.Throws<ArgumentOutOfRangeException>(() => database.FindById(-1));
        }
        [Test]
        public void testConstructor()
        {
            Database database = new Database();
            for (int i = 0; i < 16; i++)
            {
                Person person = new Person(i, $"c{i}");
                database.Add(person);
            }
            Person person1 = new Person(26, "vv");
            Assert.Throws<InvalidOperationException>(() => database.Add(person1));
        }
    }
}