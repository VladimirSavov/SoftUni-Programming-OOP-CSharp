﻿namespace FightingArena.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class ArenaTests
    {
        [Test]
        public void AlreadyEnrolledWarriors()
        {
            //Arrange
            Arena arena = new Arena();
            Warrior warrior = new Warrior("Niki", 10, 40);
            //Act
            arena.Enroll(warrior);
            //Assert
            Assert.Throws<InvalidOperationException>(() => arena.Enroll(warrior));
        }
        [Test]
        public void ThereCannotBeAFight()
        {
            //Arrange
            Arena arena = new Arena();
            Warrior warrior = new Warrior("Niki", 10, 40);
            Warrior EnemyWarrior = new Warrior("Misho", 10, 40);
            //Act
            arena.Enroll(warrior);
            //Assert
            Assert.Throws<InvalidOperationException>(() => arena.Fight("Niki", "Misho"));
        }
    }
}
