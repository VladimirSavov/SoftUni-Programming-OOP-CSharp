namespace FightingArena.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class WarriorTests
    {
        [Test]
        [TestCase("Kiril", 50, 60)]
        [TestCase("Niki", 20, 80)]
        [TestCase("Pesho", 100, 20)]
        public void TestConstructor(
            string name,
            int damage,
            int hp)
        {
            //Arrange
            Warrior warrior = new Warrior(name, damage, hp);
            //Assert
            Assert.AreEqual(name, warrior.Name);
            Assert.AreEqual(damage, warrior.Damage);
            Assert.AreEqual(hp, warrior.HP);
        }
        [Test]
        [TestCase(" ")]
        [TestCase(null)]
        [TestCase("")]
        public void NameCannotBeNull(string name)
        {
            //Arrange and Assert
            Assert.Throws<ArgumentException>(() => new Warrior(name, 10, 10));
        }
        [Test]
        [TestCase(0)]
        [TestCase(-44)]
        public void DamageCannotBeZero(int damage)
        {
            //Arrange and Assert
            Assert.Throws<ArgumentException>(() => new Warrior("Gosho", damage, 13));
        }
        [Test]
        [TestCase(-2)]
        [TestCase(-222)]
        public void HPCannotBe(int hp)
        {
            //Arange and Assert
            Assert.Throws<ArgumentException>(() => new Warrior("Gosho", 10, hp));
        }
        [Test]
        [TestCase(20)]
        [TestCase(0)]
        [TestCase(10)]
        public void WarriorCannotAttackIfHisHP(int hp)
        {
            Warrior warrior = new Warrior("Niki", 10, hp);
            Assert.Throws<InvalidOperationException>(() => warrior.Attack(warrior));
        }
        [Test]
        [TestCase(20)]
        [TestCase(0)]
        [TestCase(10)]
        public void WarriorCannotAttackWarriors(int hp)
        {
            Warrior warrior = new Warrior("Niki", 10, 40);
            Warrior EnemyWarrior = new Warrior("Stoyan", 10, hp);
            Assert.Throws<InvalidOperationException>(() => warrior.Attack(EnemyWarrior));

        }
        [Test]
        [TestCase(50)]
        [TestCase(60)]
        [TestCase(100)]
        public void WarriorCannotAttacStrongerkEnemies(int damage)
        {
            Warrior warrior = new Warrior("Niki", 10, 40);
            Warrior EnemyWarrior = new Warrior("Stoyan", damage, 50);
            Assert.Throws<InvalidOperationException>(() => warrior.Attack(EnemyWarrior));

        }
    }
}