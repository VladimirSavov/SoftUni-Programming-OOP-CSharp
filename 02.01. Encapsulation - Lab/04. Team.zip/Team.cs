﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonsInfo
{
    internal class Team
    {
        private string name;
        private List<Person> firstTeam;
        private List<Person> reserveTeam;
        public Team(string name)
        {
            this.name = name;
            firstTeam = new List<Person>();
            reserveTeam = new List<Person>();
            
        }
        public string Name { get; set; }
        public List<Person> FirstTeam { get; private set; }
        public List<Person> ReverseTeam { get; private set; }
        public void AddPlayer(Person person)
        {
            if(person.Age < 40)
            {
                firstTeam.Add(person);
            }
            else
            {
                reserveTeam.Add(person);
            }
        }
        public override string ToString()
        {
            return @$"First team has {firstTeam.Count} players.
Reverse team has {reserveTeam.Count} players.";
        }
    }
}
