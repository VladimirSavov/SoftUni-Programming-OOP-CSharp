﻿namespace tests;
public class StartUp
{
    static void Main(string[] args)
    {
    }
}
