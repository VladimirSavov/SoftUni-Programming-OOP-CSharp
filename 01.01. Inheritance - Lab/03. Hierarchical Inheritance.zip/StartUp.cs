﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomRandomList
{
    public class StartUp
    {
        static void Main()
        {
            RandomList strings = new RandomList();
            strings.Add("1");
            strings.Add("2");
            strings.Add("3");
            strings.Add("4");
            strings.Add("5");
            strings.RemoveRandomString();
            strings.RemoveRandomString();
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(strings.GetRandomsElements());
            }
        }
    }
}
