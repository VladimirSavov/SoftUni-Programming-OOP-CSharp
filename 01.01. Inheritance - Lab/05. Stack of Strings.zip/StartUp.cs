﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomStack
{
    public class StartUp
    {
        static void Main()
        {
            var list = new List<string>();
            list.Add("5");
            list.Add("4");
            list.Add("3");
            list.Add("2");
            list.Add("1");
            list.Add("0");
            StackOfStrings strings = new StackOfStrings();
            Console.WriteLine(strings.IsEmpty());
            strings.AddRange(list);
            Console.WriteLine(strings.IsEmpty());
        }
    }
}
