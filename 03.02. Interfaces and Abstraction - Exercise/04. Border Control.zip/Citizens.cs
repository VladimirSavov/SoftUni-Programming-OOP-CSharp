﻿using PersonInfo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonInfo
{
    internal class Citizens : IIdentifiable
    {
        public Citizens(string name, string age, string id)
        {
            Id = id;
            Name = name;
            Age = age;
        }

        public string Id { get; set; }
        public string Name { get; set; }
        public string Age { get; set; }
    }
}
