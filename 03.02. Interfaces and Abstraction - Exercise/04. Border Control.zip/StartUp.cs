﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonInfo
{
    public class StartUp
    {
        static void Main()
        {
            List<IIdentifiable> list = new List<IIdentifiable>();
            string input = Console.ReadLine();
            while (input != "End")
            {
                string[] inputArr = input.Split();
                IIdentifiable identifiable = null;
                if(inputArr.Length == 2)
                {
                    identifiable = new Robots(inputArr[0], inputArr[1]);
                }
                else
                {
                    identifiable = new Citizens(inputArr[0], inputArr[1], inputArr[2]);
                }
                list.Add(identifiable);
                input = Console.ReadLine();
            }
            string endDigits = Console.ReadLine();
            foreach (var item in list)
            {
                if (item.Id.EndsWith(endDigits))
                {
                    Console.WriteLine(item.Id);
                }
            }
        }
    }
}
