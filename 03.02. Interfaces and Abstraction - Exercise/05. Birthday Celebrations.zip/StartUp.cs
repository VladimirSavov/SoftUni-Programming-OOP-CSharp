﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BirthdayCelebrations
{
    public class StartUp
    {
        static void Main()
        {
            List<IIdentify> identifyList = new List<IIdentify>();   
            string[] input = Console.ReadLine().Split().ToArray();
            while (input[0] != "End")
            {
                IIdentify identify = null;
                if (input[0] == "Citizen")
                {
                    identify = new Citizen(input[1], input[2], input[3], input[4]);
                }
                else if (input[0] == "Robot")
                {
                    identify = new Robot(input[1], input[2]);
                }
                else if (input[0] == "Pet")
                {
                    identify = new Pet(input[1], input[2]);
                }
                identifyList.Add(identify);
                input = Console.ReadLine().Split().ToArray();
            }
            string year = Console.ReadLine();
            bool isEmpty = true;
            foreach (var item in identifyList)
            {
                if(item.Birthdate != null)
                {
                    string birthdate = item.Birthdate.ToString();
                    string[] splitDate = birthdate.Split('/').ToArray();
                    if(year == splitDate[2])
                    {
                        Console.WriteLine(item.Birthdate);
                        isEmpty = false;
                    }

                }
            }
            if (isEmpty)
            {
                Console.WriteLine("<empty output>");
            }
        }
    }
}
