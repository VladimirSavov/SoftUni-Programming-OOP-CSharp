﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BirthdayCelebrations
{
    public class Pet : IIdentify
    {
        public string Name { get; set; }
        public string Age { get; set; }
        public string Id { get; set; }
        public string Birthdate { get; set; }
        public string Model { get; set; }

        public Pet(string name, string birthday)
        {
            this.Name = name;
            this.Birthdate = birthday;
        }
    }
}
