﻿using SoftUni;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Telephony
{
    public class StartUp
    {
        static void Main()
        {
            List<Smartphone> smartList = new List<Smartphone>();
            List<StationaryPhone> stationList = new List<StationaryPhone>();
            string[] phoneNumbers = Console.ReadLine().Split().ToArray();
            string[] websites = Console.ReadLine().Split();

            for (int i = 0; i < phoneNumbers.Length; i++)
            {
                string currNumber = phoneNumbers[i].ToString();
                if (currNumber.Length == 10)
                {
                    if (IsValidNumber(currNumber))
                    {
                        Smartphone smartphone = new Smartphone(currNumber);
                        smartList.Add(smartphone);
                    }
                }
                else if (currNumber.Length == 7)
                {
                    if (IsValidNumber(currNumber))
                    {
                        StationaryPhone stationaryPhone = new StationaryPhone(currNumber);
                        stationList.Add(stationaryPhone);
                    }
                }
            }
            foreach (var phone in smartList)
            {
                Console.WriteLine(phone);
            }
            foreach (var phone in stationList)
            {
                Console.WriteLine(phone);
            }
            for (int i = 0; i < websites.Length; i++)
            {
                bool isTrue = true;
                string currWeb = websites[i];
                for (int k = 0; k < currWeb.Length; k++)
                {
                    char c = currWeb[k];
                    if (char.IsDigit(c))
                    {
                        isTrue = false;
                    }
                }
                if (isTrue)
                {
                Console.WriteLine($"Browsing: {currWeb}!");
                }
                else
                {
                    Console.WriteLine($"Invalid URL!");
                }
            }
            bool IsValidNumber(string number)
            {
                for (int i = 0; i < number.Length; i++)
                {
                    char c = number[i];
                    if (!char.IsDigit(c))
                    {
                        return false;
                    }
                }
                return true;
            }
        }
    }
}
