﻿using SoftUni;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Telephony
{
    public class Smartphone : IIdentify
    {
        public Smartphone(string number)
        {
            this.number = number;
        }

        public string number { get; set; }

        public override string ToString()
        {
            return $"Calling... {number}";
        }
    }
}
