﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftUni
{
    internal class Browse
    {
        public List<string> isValidURL(string[] url)
        {
            List<string> validURL = new List<string>();
            for (int i = 0; i < url.Length; i++)
            {
                string currURL = url[i];
                for (int k = 0; k < currURL.Length; k++)
                {
                    char c = currURL[k];
                    if (char.IsDigit(c))
                    {
                        break;
                    }
                }
                validURL.Add(currURL);
            }
            return validURL;
        }
    }
}
