﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftUni
{
    internal class StationaryPhone : IIdentify
    {
        public StationaryPhone(string number)
        {
            this.number = number;
        }

        public string number { get; set; }

        public override string ToString()
        {
            return $"Dialing... {number}";
        }
    }
}
