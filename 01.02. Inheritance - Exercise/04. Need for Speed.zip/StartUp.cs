﻿namespace NeedForSpeed
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Motorcycle motor = new Motorcycle(40, 20);
            System.Console.WriteLine(motor.FuelConsumption);
        }
    }
}
