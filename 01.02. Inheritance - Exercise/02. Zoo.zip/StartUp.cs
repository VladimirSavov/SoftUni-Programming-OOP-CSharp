﻿using System;
using System.Security.AccessControl;

namespace Zoo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string word = Console.ReadLine();
            Lizard lizard = new Lizard(word);
            Console.WriteLine(lizard);
        }
    }
}